# 📖 2024/2025 Academic Timetable (Website)  

A structured **academic timetable website** displaying schedules for Year 7 to Year 11. Designed using **HTML and CSS**, this project focuses on clarity, accessibility, and a well-organized layout.  

---

## 🌍 Project Summary  

This website presents a **static timetable** for students and teachers, making it easy to view daily schedules. The design ensures:  

✔ **Simple and clear timetable structure.**  
✔ **Responsive layout for different devices.**  
✔ **Easy navigation with well-defined time slots.**  

---

## 📂 Project Files

📁 Timetable Website
├── 📄 index.html         → Main webpage
├── 🎨 style.css          → Styling and design
└── 🖼️ timetable_preview.png → Preview image of the timetable

---

## 🔹 Viewing the Website  

1. **Open `index.html`** in a web browser.  
---

## 👤 Author  

📛 **Name:** Lucy Kariuki
📞 **Phone:** +254 100 253075
📧 **Email:** kariukilucie15@gmail.com
